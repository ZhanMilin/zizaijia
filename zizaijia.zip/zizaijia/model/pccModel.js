const db=require("../DB/dbconfig")
const pccModel={
    myOrder:function (param,cb) {
        let sql="SELECT * FROM userorder uo JOIN userorderproduct uop ON uo.uo_id=uop.uo_id JOIN product p ON uop.product_id=p.product_id JOIN tempadd te ON uo.tempAdd_id=te.tempAdd_id  WHERE uo.user_id=?"
        db.connection(sql,param,cb)
    },
    personalInfo:function (param,cb) {
        let sql="select userInfo_phone,userInfo_img,userInfo_name,userInfo_sex,userInfo_nickname,userInfo_email,DATE_FORMAT(userInfo_birthday,'%Y-%m-%d') as userInfo_birthday from userinfo where userInfo_phone=?"
        db.connection(sql,param,cb)
    },
    //上传图片
    userHeadImg:function (param,cb) {
        let sql="update userinfo set userInfo_img=? where userInfo_phone=?"
        db.connection(sql,param,cb)
    },
    //保存资料
    saveData:function (param,cb) {
        let sql="update userinfo set userInfo_name=?,userInfo_sex=?,userInfo_birthday=?,userInfo_nickname=?,userInfo_email=? where userInfo_phone=?"
        db.connection(sql,param,cb)
    },
    //匹配密码
    matchPwd:function (param,cb) {
        let sql="select * from userinfo where user_pwd=? and userInfo_phone=?"
        db.connection(sql,param,cb)
    },
    //修改密码
    changPwd:function (param,cb) {
        let sql="update userinfo set user_pwd=? where userInfo_phone=?";
        db.connection(sql,param,cb)
    },
    //配送地址
    userAddress:function (param,cb) {
        let sql="select * from useradd join userinfo on useradd.user_id=userinfo.user_id where userinfo.userInfo_phone=?"
        db.connection(sql,param,cb)
    },
    //添加地址
    myAddress:function (param,cb) {
        let sql="insert into useradd (username,userTel,userAdd_pro,userAdd_city,userAdd_district,userAdd_add,user_id) values(?,?,?,?,?,?,(select user_id from userinfo where userInfo_phone=?))"
        db.connection(sql,param,cb)
    },
    //编辑地址获取用户地址信息
    compileAdd:function (param,cb) {
        let sql="select * from useradd where userAdd_id=? and user_id=?"
        db.connection(sql,param,cb)
    },
    //编辑地址修改数据库
    alterAddress:function (param,cb) {
        let sql="update useradd set username=?,userTel=?,userAdd_pro=?,userAdd_city=?,userAdd_district=?,userAdd_add=? where user_id=? and userAdd_id=?"
        db.connection(sql,param,cb)
    },
    //删除用户地址
    deleteAdd:function (param,cb) {
        let sql="delete from useradd where userAdd_id=?"
        db.connection(sql,param,cb)
    },
    //我的优惠券
    myCoupon:function (param,cb) {
        let sql="select DATE_FORMAT(dis_getTime,'%Y-%m-%d') as getTime,DATE_FORMAT(dis_validTime,'%Y-%m-%d') as validTime,dis_falg,dis_num,dis_img from userdiscounts join discountinfo on userdiscounts.dis_id=discountinfo.dis_id where user_id=?"
        db.connection(sql,param,cb)
    },
    //查询用户已使用优惠券信息
    userHasUse:function (param,cb) {
        let sql="select DATE_FORMAT(dis_getTime,'%Y-%m-%d') as getTime,DATE_FORMAT(dis_validTime,'%Y-%m-%d') as validTime,dis_falg,dis_num,dis_img from userdiscounts join discountinfo on userdiscounts.dis_id=discountinfo.dis_id where user_id=? and dis_falg=2"
        db.connection(sql,param,cb)
    },
    //查询用户可使用优惠券信息
    userEnable:function (param,cb) {
        let sql="select DATE_FORMAT(dis_getTime,'%Y-%m-%d') as getTime,DATE_FORMAT(dis_validTime,'%Y-%m-%d') as validTime,dis_falg,dis_num,dis_img from userdiscounts join discountinfo on userdiscounts.dis_id=discountinfo.dis_id where user_id=? and dis_falg=1"
        db.connection(sql,param,cb)
    },
    //查询用户已过期优惠券信息
    userStale:function (param,cb) {
        let sql="select DATE_FORMAT(dis_getTime,'%Y-%m-%d') as getTime,DATE_FORMAT(dis_validTime,'%Y-%m-%d') as validTime,dis_falg,dis_num,dis_img from userdiscounts join discountinfo on userdiscounts.dis_id=discountinfo.dis_id where user_id=? and dis_falg=3"
        db.connection(sql,param,cb)
    },
    //用户查询待付款订单信息
    myObligation:function (param,cb) {
        let sql = "SELECT * FROM userorder uo JOIN userorderproduct uop ON uo.uo_id=uop.uo_id JOIN product p ON uop.product_id=p.product_id JOIN tempadd te ON uo.tempAdd_id=te.tempAdd_id  WHERE uo.user_id=? and uo.uo_status=1"
        db.connection(sql, param, cb)
    },
    //用户查询待发货订单信息
    mySendGood:function (param,cb) {
        let sql = "SELECT * FROM userorder uo JOIN userorderproduct uop ON uo.uo_id=uop.uo_id JOIN product p ON uop.product_id=p.product_id JOIN tempadd te ON uo.tempAdd_id=te.tempAdd_id  WHERE uo.user_id=? and uo.uo_status=2"
        db.connection(sql, param, cb)
    },
    //用户查询待收货订单信息
    myTrs:function (param,cb) {
        let sql = "SELECT * FROM userorder uo JOIN userorderproduct uop ON uo.uo_id=uop.uo_id JOIN product p ON uop.product_id=p.product_id JOIN tempadd te ON uo.tempAdd_id=te.tempAdd_id  WHERE uo.user_id=? and uo.uo_status=3"
        db.connection(sql, param, cb)
    },
    //用户查询已完成订单信息
    myFinish:function (param,cb) {
        let sql = "SELECT * FROM userorder uo JOIN userorderproduct uop ON uo.uo_id=uop.uo_id JOIN product p ON uop.product_id=p.product_id JOIN tempadd te ON uo.tempAdd_id=te.tempAdd_id  WHERE uo.user_id=? and uo.uo_status=4"
        db.connection(sql, param, cb)
    },
    //用户查询所有订单信息
    myUserOrder:function (param,cb) {
        let sql = "SELECT * FROM userorder uo JOIN userorderproduct uop ON uo.uo_id=uop.uo_id JOIN product p ON uop.product_id=p.product_id JOIN tempadd te ON uo.tempAdd_id=te.tempAdd_id  WHERE uo.user_id=?"
        db.connection(sql, param, cb)
    },
    //用户删除订单信息
    deleteOrder:function (param,cb) {
        let sql="DELETE FROM userorder where uo_id=? and user_id=?"
        db.connection(sql,param,cb)
    },
    //用户批量删除订单
    myDeleteBatch:function (sql,param,cb) {
        db.connection(sql,param,cb)
    },
    //用户设置默认地址
    defaultAdd:function (param,cb) {
        let sql="update useradd set userAdd_status=1 where userAdd_id=? and user_id=?"
        db.connection(sql,param,cb)
    },
    //设置所有地址状态为0;
    changeAddStatus:function (param,cb) {
        let sql="update useradd set userAdd_status=0 where user_id=?"
        db.connection(sql,param,cb)
    },
    //用户消息
    myMsg:function (param,cb) {
        let sql="select userMsg_id,userMsg_title,userMsg_content,DATE_FORMAT(userMsg_date,'%Y-%m-%d') as userMsg_date,userMsg_status from usermsg where user_id=?"
        db.connection(sql,param,cb)
    },
    //用户查看消息后改变消息状态
    changeMsgStatus:function (param,cb) {
        let sql = "update usermsg set userMsg_status=1 where userMsg_id=? and user_id=?"
        db.connection(sql,param,cb)
    },
    //获取消息内容
    getMsgContent:function (param,cb) {
        let sql="select userMsg_id,userMsg_title,userMsg_content,DATE_FORMAT(userMsg_date,'%Y-%m-%d') as userMsg_date,userMsg_status from usermsg where userMsg_id=? and user_id=?"
        db.connection(sql,param,cb)
    },
    //用户查询所有消息
    userAllMsg:function (param,cb) {
        let sql="select userMsg_id,userMsg_title,userMsg_content,DATE_FORMAT(userMsg_date,'%Y-%m-%d') as userMsg_date,userMsg_status from usermsg where user_id=?"
        db.connection(sql,param,cb)
    },
    //用户查询新消息
    userNewMsg:function (param,cb) {
        let sql="select userMsg_id,userMsg_title,userMsg_content,DATE_FORMAT(userMsg_date,'%Y-%m-%d') as userMsg_date,userMsg_status from usermsg where user_id=? and userMsg_status=0"
        db.connection(sql,param,cb)
    },
    //用户查询新消息
    userReadyMsg:function (param,cb) {
        let sql="select userMsg_id,userMsg_title,userMsg_content,DATE_FORMAT(userMsg_date,'%Y-%m-%d') as userMsg_date,userMsg_status from usermsg where user_id=? and userMsg_status=1"
        db.connection(sql,param,cb)
    },
    //我的收藏
    collect:function (param,cb){
        let sql="select * from usercollect join product on usercollect.product_id=product.product_id where user_id=?"
        db.connection(sql,param,cb)
    },
    //用户删除我的收藏
    deleteMyCollect:function (param,cb) {
        let sql="delete from usercollect where uc_id=?"
        db.connection(sql,param,cb)
    },
    //用户确认收货改变订单状态
    goodProduct:function (param,cb) {
        let sql = "update userorder set uo_status=4 where uo_id=? and user_id=?"
        db.connection(sql,param,cb)
    }
}
module.exports=pccModel