const db=require("../DB/dbconfig")
const orderNumModel={
    showOrderNumModel: function (param, cb) {
        // let sql = "SELECT uo_id,uo_money FROM userorder WHERE user_id=? ORDER BY uo_id DESC LIMIT 0,1"
        let sql = "SELECT uo_money FROM userorder WHERE user_id=? and uo_id=?"
        // console.log(sql)
        db.connection(sql, param, cb)
    },
    changeStatusModel:function (param,cb) {
        let sql = "UPDATE userorder SET uo_status=2 WHERE user_id= ? and uo_id=?"
        db.connection(sql, param, cb)
    }
}
module.exports = orderNumModel;