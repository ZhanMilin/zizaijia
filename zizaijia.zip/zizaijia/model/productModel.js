const dbconfig = require("../DB/dbconfig.js");
function getProductList1(sql,param,cb){
    dbconfig.connection(sql,param,cb)
}
function getPageCount1(sql,param,cb){
    dbconfig.connection(sql,param,cb)
}
// function getStyle1(cb){
//     let sql = "SELECT DISTINCT product_style  FROM product";
//     dbconfig.connection(sql,[],cb)
// }
module.exports = {
    getProductList:getProductList1,
    getPageCount:getPageCount1,
    // getStyle:getStyle1
};
