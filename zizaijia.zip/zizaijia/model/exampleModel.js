const dbconfig = require("../DB/dbconfig.js");
function myexampleInfo(param,cb){
    let sql = "SELECT product_cover,product_sale,product_name,product_id,class_name from product JOIN class ON product.class_id=class.class_id WHERE " +
        "product_style=? AND product_place='客厅'";
    dbconfig.connection(sql,param,cb)
}

/*function getPageCount1(param,cb){
    let sql = "SELECT COUNT(*) AS pagecount FROM product WHERE product_style=? AND product_place='客厅'";
    dbconfig.connection(sql,param,cb);
}*/
module.exports = {
    exampleInfo:myexampleInfo,

   // getPageCount:getPageCount1
}