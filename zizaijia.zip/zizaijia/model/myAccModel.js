// const db=require("./../DB/dbconfig")
// module.exports={
//     queryUserInfo:function (param,cb) {
//         let sql="select count(*) as design from "
//     }
// }