const db=require("../DB/dbconfig.js")
const myUserModel={
    userLoginModel:function (param,cb) {
        let sql="select * from userinfo where userInfo_phone=? and user_pwd=?"
        db.connection(sql,param,cb)
    },
    usernameLogin:function (param,cb) {
        let sql="select * from userinfo where userInfo_phone=?"
        db.connection(sql,param,cb)
    },
    usernameCode:function (param,cb) {
        let sql="select * from userinfo where userInfo_phone=?"
        db.connection(sql,param,cb)
    },
    regUserAdd:function (param,cb) {
        let sql="insert into userinfo(userInfo_phone,user_pwd,userInfo_regDate) values (?,?,?)"
        db.connection(sql,param,cb)
    },
    updatePwd:function (param,cb) {
        let sql="update userinfo set user_pwd=? where userInfo_phone=?"
        db.connection(sql,param,cb)
    },
    //发送消息给用户
    userAddMsg:function (param,cb) {
        let sql="insert into usermsg(user_id,userMsg_title,userMsg_content,userMsg_date,userMsg_status) values (?,?,?,?,?)"
        db.connection(sql,param,cb)
    },
    //查询用户信息
    queryUserInfo:function (param,cb) {
        let sql="select user_id from userinfo where userInfo_phone=?"
        db.connection(sql,param,cb)
    },
    //更改用户登陆时间
    addLastDate:function (param,cb) {
        let sql="update userinfo set lastLogin=? where userInfo_phone=?"
        db.connection(sql,param,cb)
    }

}
module.exports=myUserModel