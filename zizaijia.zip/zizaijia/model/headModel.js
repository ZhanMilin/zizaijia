const db = require("../DB/dbconfig.js")
let headInfo = {
    getUserImg:function (userName,cb) {
        let sql = "select userInfo_img,userInfo_phone from userInfo where userInfo_phone = ?"
        db.connection(sql,userName,cb)
    },
    // headSearch:function (searchText,cb) {
    //     let sql =
    // }
}
module.exports = headInfo