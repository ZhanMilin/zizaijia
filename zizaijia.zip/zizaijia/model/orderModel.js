const db = require("../DB/dbconfig.js")
let orderInfo = {
    addAddress:function (addPrame,cb) {
        let sql = "insert into useradd(user_id,userAdd_pro,userAdd_city,userAdd_district,userAdd_add,username,userTel)" +
            " values(?,?,?,?,?,?,?)"
        db.connection(sql,addPrame,cb)
    },
    updateAddress:function (addPrame,cb) {
        let sql = "update useradd set userAdd_pro=?,userAdd_city=?,userAdd_district=?,userAdd_add=?,username=?,userTel=?" +
            " where userAdd_id=?"
        db.connection(sql,addPrame,cb)
    },
    getUserAdd:function (userId, cb2) {
        let sql = "select * from useradd where user_id=?"
        db.connection(sql,userId,cb2)
    },
    getAdd:function (addId, cb) {
        let sql = "select * from useradd where userAdd_id=?"
        db.connection(sql,addId,cb)
    },
    getDiscount:function (userId, cb1) {
        let sql = "SELECT * FROM userdiscounts aa JOIN discountinfo bb ON aa.dis_id=bb.dis_id AND aa.user_id=? AND aa.dis_falg=1"
        db.connection(sql,userId,cb1)
    },
    getProductInfo:function (id, cb3) {
        let sql = "select * from myorder where sc_id=?"
        db.connection(sql,id,cb3)
    },
    getProductImg:function (myProductId, cb4) {
        let sql = "select * from product where product_id=?"
        db.connection(sql,myProductId, cb4)
    },
    addTempAdd:function (addInfo, cb1) {
        let sql = "insert into tempadd(tempAdd_pro,tempAdd_city,tempAdd_district,tempAdd_add,tempAdd_name,tempAdd_phone)" +
            " values(?,?,?,?,?,?)"
        db.connection(sql,addInfo,cb1)
    },
    addOrderInfo:function (orderInfo, cb2) {
        let sql = "insert into userorder(user_id,tempAdd_id,uo_status,uo_money,uo_date)" +
            " values(?,?,?,?,?)"
        db.connection(sql,orderInfo,cb2)
    },
    getProductId:function (productInfo, cb3) {
        let sql = "select product_id,product_num from myorder where sc_id=?"
        db.connection(sql, productInfo, cb3)
    },
    addOrderProduct:function (myData, cb4) {
        let sql = "insert into userorderproduct(uo_id,product_id,uo_p_num)" +
            " values(?,?,?)"
        db.connection(sql, myData, cb4)
    }
}
module.exports = orderInfo