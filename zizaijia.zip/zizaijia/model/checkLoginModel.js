const db=require("../DB/dbconfig")
const lotteryModel= {
    lotteryTimesModel: function (param, cb) {
        let sql = "select userInfo_lotteryFlag from userinfo where userInfo_phone=?"
        db.connection(sql, param, cb)
    },
    lotteryFlagModel: function (param, cb) {
        let sql = "UPDATE userinfo SET userInfo_lotteryFlag=0 WHERE userInfo_phone=?"
        db.connection(sql, param, cb)
    },
    discountModel: function (user_id,param, cb) {
        let sql="";
        // console.log(user_id)
        // console.log(param)
        param=param.split(",")
        // console.log(param.length)
        sql=" INSERT INTO userdiscounts  VALUES"
        for(var i=0;i<param.length;i++){
           sql+="("+user_id+","+param[i]+",NOW(),DATE_ADD(NOW(), INTERVAL 3 MONTH),1),"
        }
        sql=sql.substr(0,sql.length-1)+";"       //抽取字符串，从第一个开始，到倒数第二个，也就是去掉最后一个逗号
        // console.log(sql)
        db.connection(sql, [], cb)
    }
}
module.exports=lotteryModel;