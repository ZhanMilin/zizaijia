const db = require("../DB/dbconfig");
module.exports={
    carModel:function (param,cb) {
        let sql = "SELECT product_cover,shoppingproduct.product_id,product_name,SUM(shoppingproduct.product_num) AS product_num,product_size,SUM(product_money) as product_money,class_name FROM shoppingproduct JOIN product ON shoppingproduct.product_id=product.product_id JOIN class ON product.class_id=class.class_id\n" +
            "WHERE user_id =?\n" +
            "GROUP BY product_id"
        db.connection(sql,param,cb)
    },
    delCarModel:function (param,cb) {
        let sql ="delete from shoppingproduct WHERE product_id=? and user_id=?"
        db.connection(sql,param,cb)
    },
    checkDelModel:function (param,cb) {
        let sql ="delete from shoppingproduct WHERE product_id in ("
        for (var i=0;i<param.length;i++){
            if(i==param.length-1){
                sql+="and user_id=?"
            } else if(i==param.length-2){
                sql+="?)"
            }else {
                sql+="?,"
            }
        }
        db.connection(sql,param,cb)
    },
    cartModel:function(param,cb){
        let sql ="INSERT INTO  shoppingcart(user_id) VALUES(?)"
        db.connection(sql,param,cb)
    },
    toOrderModel:function (param,cb) {
        let sql="";
        let myparam=[];
        for(var i=0;i<param.length;i++){
            if(i==0){
                sql +="INSERT INTO myorder(product_id,product_size,product_num,product_money,sc_id) VALUES (?,?,?,?,?)"
            }else{
                sql +=",(?,?,?,?,?)"
            }
            for( let key in param[i]){
                myparam.push(param[i][key])
            }

        }
        db.connection(sql,myparam,cb)
    },
    toModel:function (param,cb) {
        let sql="UPDATE shoppingproduct SET product_num=? ,product_money=? where product_id=? and user_id=?"
        db.connection(sql,param,cb)
    }
}