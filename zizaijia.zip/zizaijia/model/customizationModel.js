 //模型层，用于修改模型的样本
const db=require("./../db/dbconfig.js");      //引用数据库
 //——————床————————
function myhead(cb){    //模型层进行数据库的操作
    let sql="SELECT * FROM customoption WHERE custom_id=1";
    db.connection(sql,[],cb)    //连接数据库
}
 function myead(cb){
     let sql="SELECT * FROM customstyle WHERE custom_id=1 or custom_id=2";
     db.connection(sql,[],cb)
 }
function bedHead(cb,parem,sql){
    db.connection(sql,parem,cb)
}
function bedBedside(cb,parem){
    let sql="SELECT ca_id,ca_img FROM customachieve WHERE head_name=? AND foot_name=? AND color_name=?";
    db.connection(sql,parem,cb)
}
 function stock(cb,parem){
     let sql="SELECT ca_id,ca_img FROM customachieve WHERE head_name=? AND foot_name=? AND color_name=?";
     db.connection(sql,parem,cb)
 }
 function col(cb,parem){
     let sql="SELECT ca_id,ca_img FROM customachieve WHERE head_name=? AND foot_name=? AND color_name=?";
     db.connection(sql,parem,cb)
 }
 function Com(cb,parem){
     let sql="INSERT INTO commodity (user_id,ca_id) VALUES (?,?)";
     db.connection(sql,parem,cb)
 }
module.exports={
    getHead:myhead,
    gethead:myead,
    mytest:bedHead,
    myBedside:bedBedside,
    myTailStock:stock,
    myCcolor:col,
    myCommodity:Com

}