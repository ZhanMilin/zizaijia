const express=require("express")
const router=express.Router()
const userControl=require("./../controller/userControl.js")
//用户账号密码登录接口
router.route("/userLogin.do").post(userControl.userLogin)
//用户名核实
router.route("/username.do").post(userControl.username)
//用户短信快捷登录手机号验证
router.route("/usernameCode.do").post(userControl.usernameCode)
//用户短信快捷登录发送短信验证码
router.route("/noteLoginCode.do").post(userControl.getNoteLogin)
//用户短信快捷登录登录验证
router.route("/noteLogin.do").post(userControl.noteLogin)
//注册短信码发送
router.route("/regNoteCode.do").post(userControl.getNoteLogin)
//注册获取验证码检测是否注册过
router.route("/regTelCode.do").post(userControl.username)
//注册短信验证码验证
router.route("/userRegNoteCode.do").post(userControl.noteLogin)
//用户注册
router.route("/regUserAdd.do").post(userControl.regUserAdd)
//用户忘记密码发送验证码（用户验证接口）
router.route("/userForgetName.do").post(userControl.username)
//用户忘记密码页面（发送验证码）
router.route("/userForgetNote.do").post(userControl.getNoteLogin)
//用户忘记密码页面（验证码核对）
router.route("/ForgetPwdNote.do").post(userControl.noteLogin)
// 用户忘记密码页面（用密码密码验证）
router.route("/userInfo.do").post(userControl.userLogin)
//用户忘记密码页面（修改数据库密码）
router.route("/updatePwd.do").post(userControl.updatePwd)
//用户数据缓存
router.route("/checkLogin.do").post(userControl.checkLogin)
module.exports=router