const express = require("express")
const router = express.Router()
const paymentController = require("../controller/paymentController.js")

router.route("/orderNum.do").post(paymentController.showOrderNum)
router.route("/changeStatus.do").post(paymentController.changeStatus)
module.exports = router