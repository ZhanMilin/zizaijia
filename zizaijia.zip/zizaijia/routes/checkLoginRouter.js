const express = require("express")
const router = express.Router()
const checkLoginController = require("../controller/checkLoginController.js")

router.route("/lotteryCheckLogin.do").post(checkLoginController.checkLogin)
router.route("/lotteryTimes.do").post(checkLoginController.lotteryTimes)
router.route("/lotteryFlag.do").post(checkLoginController.lotteryFlag)
router.route("/discount.do").post(checkLoginController.discountController)

module.exports = router