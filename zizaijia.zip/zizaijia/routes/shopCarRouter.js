const shopCarController = require("../controller/shopCarController")
const router = require("express").Router();
router.route("/shop.do").get(shopCarController.carControl)
router.route("/delete.do").post(shopCarController.delCar)
router.route("/allDelete.do").post(shopCarController.allDelCar)
router.route("/order.do").post(shopCarController.orderControl)
router.route("/to.do").post(shopCarController.toControl)
module.exports=router;