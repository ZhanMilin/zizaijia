const personControl = require("../controller/customizationController.js")   //调用控制器
const express = require("express");
const router =express.Router();
// ————————床头————————————
router.route("/pj.do")
    .get(personControl.bedHead);

router.route("/docum.do")
    .get(personControl.bedH);

router.route("/test.do")
    .post(personControl.testbed);

//三个选项分别判断轮播图
//床头来判断
router.route("/bedside.do")
    .post(personControl.bedside);
//床尾来判断
router.route("/chuangwei.do")
    .post(personControl.mytailstock);
//颜色来判断
router.route("/ccolor.do")
    .post(personControl.ccolor);
// 定制完成后台传值
router.route("/commodity.do")
    .get(personControl.commodity);
module.exports = router;


