// const myAccControl=require("./../controller/myAccController")
// const router=require("express").Router();
// router.route("/queryUserInfo").post(myAccControl.queryUserInfo);
// module.exports=router