const express = require("express")
const router = express.Router()
const headController = require("../controller/headController.js")
router.route("/getUserName.do")
    .post(headController.headUserName)
router.route("/userExit.do")
    .get(headController.userExit)
module.exports = router