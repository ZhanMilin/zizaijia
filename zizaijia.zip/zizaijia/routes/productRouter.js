const productController = require("./../controller/productController.js");
const express = require("express");
const router = express.Router();
router.route("/productList.do").get(productController.productList);//遍历数据
router.route("/pageCount.do").get(productController.pageCount);//分页
/*router.route("/style.do").get(productController.productStyle);*/
/*router.route("/projectInfo.do").get(function (req,res) {
    res.render("mydetails");
})*/
module.exports = router;
