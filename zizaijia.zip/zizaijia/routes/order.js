const express = require("express")
const router = express.Router()
const orderController = require("../controller/orderController.js")

router.route("/addOrderAdd.do")
    .get(orderController.addOrderAdd)

router.route("/addOrderAddEjs.do")
    .get(orderController.addOrderAddEjs)

router.route("/orderEjs.do")
    .get(orderController.orderEjs)

router.route("/orderAddUpdataEjs.do")
    .get(orderController.orderAddUpdataEjs)

router.route("/updateOrderAdd.do")
    .get(orderController.orderAddUpdata)

router.route("/addOrder.do")
    .post(orderController.addOrder)

router.route("/orderAEjs.do")
    .get(orderController.orderAEjs)

module.exports = router