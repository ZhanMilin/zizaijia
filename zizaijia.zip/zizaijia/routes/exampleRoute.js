const exampleController = require("./../controller/exampleController");
const express = require("express");
 const router = express.Router();
 router.route("/pc.do").get(exampleController.example)

/* router.route("/pageCount.do").post(exampleController.pageCount);*/
 router.route("/projectInfo.do").get(function (req,res){
   res.render("mydetails")
 }
 )
 module.exports = router;
