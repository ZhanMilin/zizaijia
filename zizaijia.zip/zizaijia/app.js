﻿const express=require("express")
const app=express()
const session=require("express-session")
const bodyParser=require("body-parser")
const routerLogin=require("./routes/routerLogin.js")
const myRouter=require("./routes/LQRouter.js");//刘倩
const pccRouter=require("./routes/pccRoter.js")
const customizationRouter=require("./routes/customizationRouter.js")        //大帅比邹青谕
const headRouter=require("./routes/headRouter.js")//温新
const orderRouter=require("./routes/order.js")//温新
const shopCar=require("./routes/shopCarRouter.js")//汤圆
const product = require("./routes/productRouter.js");//卢东红
const checkLoginRouter=require("./routes/checkLoginRouter.js")//詹密林
const paymentRouter=require("./routes/paymentRouter.js")//詹密林
// const myAccRouter=require("./routes/myAccRouter.js")
app.use(session({
    cookie:{
        maxAge:7200*1000
    },
    name:"user",
    secret:"project",
    resave:true,
    rolling:true
}))
app.set("views",__dirname+"/views")
app.set("view engine","ejs")
app.use(bodyParser.urlencoded({extends:false}))
app.use(routerLogin)
app.use("/myOrder",routerLogin)
app.use(myRouter) //刘倩
app.use(product);//卢东红
app.use(pccRouter)
app.use(shopCar)
app.use(customizationRouter)      //大帅比邹青谕
app.use(headRouter)//温新
app.use(orderRouter)//温新
app.use(checkLoginRouter)//詹密林
app.use(paymentRouter )//詹密林
// app.use(myAccRouter)
app.use(express.static(__dirname+"/public"))
app.use(express.static(__dirname+"/public/HTML/"))
app.use(express.static(__dirname+"/public/HTML/index"))
app.use(express.static(__dirname+"/"))//刘倩--保留不要注销
app.use((req,res)=>{
    res.status(404).sendFile(__dirname+"/public/HTML/404.html")
})
app.listen("8888",()=>{
    console.log("服务器已启动,端口号为8888")
})
