const headModel = require("../model/headModel.js")
let headInfo = {
    headUserName:function (req,res) {
        let userName = req.session.name
        function cb(err, data) {
            if(!err&&data.length>0){
                res.send(data)
            }
        }
        if(userName!=null||userName!=undefined){
            headModel.getUserImg(userName,cb)
        }else {
            res.send("0")
        }
    },
    userExit:function (req, res) {
        req.session.name=undefined
        req.session.userId=undefined
        res.redirect("HTML/login/login.html")
    }
}
module.exports = headInfo;