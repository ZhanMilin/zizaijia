const checkLoginModel=require("../model/checkLoginModel.js")
let check = {
    checkLogin: function (req, res) {
        let userName = req.session.name
        // console.log(userName)
        if (userName != null || userName != undefined) {
            res.send("1")
        } else {
            res.send("0")
        }

    },
    //查询还有没有抽奖次数
    lotteryTimes: function (req, res) {
        let param = []
        param.push(req.session.name)

        function callback(err, data) {
            // console.log(data)
            // console.log("--------")
            // console.log(data[0].userInfo_lotteryFlag)
            if (data[0].userInfo_lotteryFlag == 1) {
                res.send("1")
            } else {
                res.send("0")
            }
        }

        checkLoginModel.lotteryTimesModel(param, callback)
    },
    //抽奖之后，修改抽奖次数
    lotteryFlag: function (req, res) {
        let param = []
        param.push(req.session.name)

        function callback(err, data) {
            if (!err) {
                res.send("1")
            } else {
                res.send("0")
            }
        }

        checkLoginModel.lotteryFlagModel(param, callback)
    },
    //把用户获得的优惠券存入数据库
    discountController:function (req, res) {
        let param = []
        let user_id=req.session.userId;
        let dis_id=req.body.dis_id;
        // console.log(dis_id);
        // console.log("-----------")
        param=dis_id;
        function callback(err, data) {
            if (!err) {
                // console.log(data)
                res.send("1")
            } else {
                res.send("0")
                // console.log(err)
            }
        }

        checkLoginModel.discountModel(user_id,param, callback)
    }
}
module.exports = check;