// const myAssModel=require("./../model/myAccModel")
// function queryUserInfo(req,res) {
//     let user=req.session.user;
//     let name=req.session.name;
//     let designData;
//     let myCollection;
//     let param=[];
//     param.push(name)
//     function callback(err,data) {
//         if(!err&&data.length>=0){
//             designData=data;
//             myAssModel.queryColl(param,callback2)
//         }
//     }
//     myAssModel.queryUserInfo(param,callback)
//     function callback2(err,data) {
//         if(!err&&data.length>0){
//             myCollection=data
//         }
//     }
// }
// module.exports={
//     queryUserInfo:queryUserInfo
// }