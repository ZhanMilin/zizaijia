const shopCarModel = require("../model/shopCarModel");
module.exports={
    carControl:function (req,res) {
        let user=req.session.userId;
        function callback(err,data){
            if(err==null && data.length>0){
                res.render("shoppingCar",{content:data})
            }else {
                res.render("shoppingCar",{content:0})
            }
        }
        shopCarModel.carModel(user,callback)
    },
    delCar:function (req,res) {
        let proID=req.body.id;
        let user=req.session.userId;
        let param=[proID,user]
        function callback(err,data) {
            if(err==null && data.length>0){
                res.send(data)
            }else{
                res.send("0")
            }
        }
        shopCarModel.delCarModel(param,callback)
    },
    allDelCar:function (req,res) {
        let delectID=req.body.id;
        let user=req.session.userId;
        let newArr=delectID.split(",")
        newArr.push(user)
        function callback(err,data) {
            if(err==null && data.length>0){
                res.send(data)
            }else{
                res.send("0")
            }
        }
        shopCarModel.checkDelModel(newArr,callback)
    },
    orderControl:function (req,res) {
        let proID=req.session.userId;
        let pro=req.body.pro;
        let checkId=req.body.id;
        checkId.push(proID)
        function callback(err,data) {
            if(err==null){
                var userid=data.insertId
                res.send(data)
                for(var i=0;i<pro.length;i++){
                    pro[i].pro_id=userid
                }
                function callback(err,data) {
                    if(err==null && data.length>0){

                    }
                }
                shopCarModel.toOrderModel(pro,callback)

            }
        }
        shopCarModel.cartModel(proID,callback)
        function callback1(err,data){
            if(err==null){

            }
        }
        console.log(checkId)
        shopCarModel.checkDelModel(checkId,callback1)
    },
    toControl:function (req,res) {
        let myNum = req.body.num
        let toPrice = req.body.mytoPrice
        let proID = req.body.id
        let userId=req.session.userId;
        let param=[myNum,toPrice,proID,userId]
        function callabck(err,data) {
            if(err==null){
                res.send("1");
            }
        }
        shopCarModel.toModel(param,callabck)
    }
}