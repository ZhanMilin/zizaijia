const userModel=require("./../model/userModel.js")
const fs=require("fs")
const AV=require("leancloud-storage")
let appId="BAWx28H3yj3LUTd7Pv68vIYc-gzGzoHsz"
let appKey="1gVVhgI4PlxGszOnjoUytr8a"
AV.init({
    appId:appId,
    appKey:appKey
})
const myUserControl={
    userLogin:(req,res)=>{
        let userLoginName=req.body.name
        let userLoginPwd=req.body.pwd
        let param=[];
        let param1=[];
        let loginDate=new Date()
        loginDate=loginDate.toLocaleDateString()
        param1.push(loginDate)
        param1.push(userLoginName)
        if(userLoginName.length>0){
            param.push(userLoginName)
        }
        if(userLoginPwd.length>0){
            param.push(userLoginPwd)
        }
        function callback(err,data) {
            if(!err&&data.length>0){
                req.session.name=userLoginName;
                req.session.userId=data[0].user_id;
                req.session.userImg=data[0].userInfo_img;
                req.session.user=data[0];
                userModel.addLastDate(param1,callback1)
            }else{
                res.send("0")
            }
        }
        function callback1(err,data) {
            if(!err){
                res.send("1")
            }
        }
        userModel.userLoginModel(param,callback)
    },
    username:(req,res)=>{
        let username=req.body.name
        let param=[]
        if(username.length>0){
            param.push(username)
        }
        function callback(err,data) {
            if(!err&&data.length>0){
                res.send("1")
            }else{
                res.send("0")
            }
        }
        userModel.usernameLogin(param,callback)
    },
    usernameCode:(req,res)=>{
        let userTel=req.body.userTel;
        let param=[];
        param.push(userTel)
        function callback(err,data) {
            if(!err&&data.length>0){
                res.send("1")
            }else{
                res.send("0")
            }
        }
        userModel.usernameCode(param,callback)
    },
    getNoteLogin:function (req,res) {
        let tel=req.body.tel
        AV.Cloud.requestSmsCode({
            mobilePhoneNumber:tel,
            name:'优乐居短信',
            op:'登录',
            ttl:10
        }).then(function () {
            res.send("1")
        }).catch(function(){res.send("0")})
    },
    noteLogin:function (req,res) {
        let tel=req.body.tel;
        let authCode=req.body.authCode;
        AV.Cloud.verifySmsCode(authCode,tel).then(function () {
            res.send("1")
        }).catch(function () {
            res.send("0")
        })
    },
    regUserAdd:(req,res)=>{
        let tel=req.body.tel;
        let pwd=req.body.pwd;
        let param=[];
        let param1=[];
        let param2=[];
        let myDate=new Date()
        myDate=myDate.toLocaleDateString()
        param.push(tel);
        param.push(pwd);
        param.push(myDate);
        param1.push(tel)
        function callback(err,data) {
            if(!err){
                userModel.queryUserInfo(param1,callback1)
            }else{
                res.send("0")
            }
        }
        function callback1(err,data) {
            if(!err){
                param2.push(data[0].user_id);
                param2.push("账户消息");
                param2.push("欢迎"+tel+"注册优乐居,快快开始选购商品吧");
                param2.push(myDate);
                param2.push(0);
                userModel.userAddMsg(param2,callback2)
            }
        }
        function callback2(err,data) {
            if(!err){
                res.send("1")
            }else{
                res.send("0")
            }
        }
        userModel.regUserAdd(param,callback)
    },
    updatePwd:(req,res)=>{
        let name=req.body.name;
        let pwd=req.body.pwd;
        let param=[];
        if(pwd.length>0){
            param.push(pwd)
        }
        if(name.length>0){
            param.push(name)
        }
        function callback(err,data) {
            if(!err){
                res.send("1")
            }else{
                res.send("0")
            }
        }
        userModel.updatePwd(param,callback)
    },
    checkLogin:(req,res)=>{
        if(req.session.name!=undefined||req.session.name!=null){
            res.send("1")
        }else{
            res.send("0")
        }
    }
}

module.exports=myUserControl