const exampleModel = require("../model/exampleModel");
function myexample(req,res){
    let numStyle = Number(req.query.numStyle);
    let style ="";
    let param=[];
    if(numStyle==1){
         style="现代都市";
    }else if(numStyle==2){
        style="田园休闲";
    }else if(numStyle==3){
        style="清新法式";
    }else{
        style="简约美式";
    }
    param.push(style);
    console.log(param);
    function callback(err,data){
        console.log(data);
        console.log("12232");
         if(err == null && data.length>0){
             res.render("product",{style:style,data:data})//product=>ejs文件的名字
         }
    }
    exampleModel.exampleInfo(param,callback);
}

// function pageCount1(req,res){
//     let dataName = req.body.dataName;
//     let param=[];
//     param.push(dataName);
//     function callback(err,data){
//          console.log(data);//47  已经得到
//             if(err == null && data.length>0){
//                 let count = Math.ceil(data[0].pagecount/12);
//                 console.log(count)
//                 res.send(String(count));
//             }else{
//                 res.send("0");
//             }
//         }
//     exampleModel.getPageCount(param,callback);
//
// }
// function myProductPage(req,res){
//     let page=(Number(req.body.page)-1)*12;
//     console.log("page"+req.body.page)
//     let param=["现代都市"];
//     param.push(2)
//     console.log("1223")
//     console.log(param)
//     function callback(err,data){
//         console.log("21321");
//         console.log(data);
//         if(!err&&data.length>0){
//             res.send(data)
//         }
//     }
//     exampleModel.exampleInfo(param,callback);
// }
module.exports = {
    example:myexample,
    /*pageCount:pageCount1,
    productPage:myProductPage*/
}