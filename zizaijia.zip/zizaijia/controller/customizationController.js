const mx=require("../model/customizationModel.js");
//————————获取右边的三个，床头床尾颜色的图片——————————
function mybedHead(req,res){
    function cb(err,data) {
        if(err==null && data.length>=0){
            // console.log(data)
            bedHeader={content:data}
           res.render("customization",bedHeader)
        }
    }
    mx.getHead(cb);    //这也是一个函数   这个函数再模型层里面  调用模型层函数
}
// ——————————获取1.8和1.5米床，柜子这些的——————
function bedh(req,res){
    function cb(err,data) {
        if(err==null && data.length>=0){
            bedHeader={content:data}
            res.render("happyCustomization",bedHeader)
        }
    }
    mx.gethead(cb);    //这也是一个函数   这个函数再模型层里面  调用模型层函数
}

// ——————————获取点击床头床尾后进入的图片————————
function mytest(req,res){
    let parem=[];
    let bedHead=req.body.bedHead;
    let bedFoot=req.body.bedFooter;
    let bedColor=req.body.bedColor;
    let sql="SELECT * FROM customachieve where 1=1"
    if(bedHead!=null&&bedHead!=""&&bedHead!=undefined){
        parem.push(bedHead)
        sql+=" AND head_name='枫语' AND ca_id=1 OR head_name='轻舞' AND ca_id=9 OR head_name='流云' AND ca_id=12 OR head_name='悦动 'AND ca_id=16"
    }
    if(bedFoot!=null&&bedFoot!=""&&bedFoot!=undefined){
        parem.push(bedFoot)
        sql+=" AND foot_name='枫语' AND ca_id=1 OR foot_name='轻舞' AND ca_id=26 OR foot_name='流云' AND ca_id=42 OR foot_name='悦动 'AND ca_id=58"
    }
    if(bedColor!=null&&bedColor!=""&&bedColor!=undefined){
        parem.push(bedColor)
        sql+=" AND color_name='飞鸟白' AND ca_id=1 OR color_name='苍穹灰' AND ca_id=2 OR color_name='华生棕' AND ca_id=3 OR color_name='木棉' AND ca_id=4"
    }
    function cb(err,data) {
        if(err==null && data.length>=0){
            res.send(data)
        }
    }
    mx.mytest(cb,parem,sql)
}
    //点击床头切换轮播图
function mybedside(req,res){
    let bedside=req.body.bedH;
    let bedfooter=req.body.bedF;
    let bedcolor=req.body.bedC;
    let parem= [];
    parem.push(bedside)
    parem.push(bedfooter)
    parem.push(bedcolor)
    // console.log(parem)
    function cb(err,data) {
        // console.log(data)
        if(err==null && data.length>=0){
            res.send(data)
        }
    }
    mx.myBedside(cb,parem)
}
//点击床尾切换轮播图
function myTailstock(req,res){
    let bedside=req.body.bedH;
    let bedfooter=req.body.bedF;
    let bedcolor=req.body.bedC;
    let parem= [];
    parem.push(bedside)
    parem.push(bedfooter)
    parem.push(bedcolor)
    // console.log(parem)
    function cb(err,data) {
        // console.log(data)
        if(err==null && data.length>=0){
            res.send(data)
        }
    }
    mx.myTailStock(cb,parem)
}
//点击颜色切换轮播图片
function myccolor(req,res){
    let bedside=req.body.bedH;
    let bedfooter=req.body.bedF;
    let bedcolor=req.body.bedC;
    let parem= [];
    parem.push(bedside)
    parem.push(bedfooter)
    parem.push(bedcolor)
    // console.log(parem)
    function cb(err,data) {
        // console.log(data)
        if(err==null && data.length>=0){
            res.send(data)
        }
    }
    mx.myCcolor(cb,parem)
}
// 定制完成后台传值
function mycommodity(req,res){
    let user_id=req.session.userId
    if(user_id==''||user_id==null||user_id==undefined){
        res.send("0")
    }else {
        let commodity=req.query.commodityId;
        let parem= [];
        parem.push(user_id)
        parem.push(commodity)
        console.log(parem)
        function cb(err,data) {
            if(err==null && data.length>=0){
                res.send("1")
            }
        }
        mx.myCommodity(cb,parem)
    }
}
module.exports= {
    bedHead:mybedHead,
    bedH:bedh,
    testbed:mytest,
    bedside:mybedside,
    mytailstock:myTailstock,
    ccolor:myccolor,
    commodity:mycommodity
};