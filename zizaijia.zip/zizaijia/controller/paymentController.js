const paymentModel=require("../model/paymentModel.js")
let orderNum= {
    showOrderNum: function (req, res) {
        let user_id = req.session.userId;
        let uo_id = req.body.uo_id;
        let param=[user_id,uo_id];
        console.log(param);
        function callback(err, data) {
            if (!err) {
                console.log(data)
                res.send(data)
            } else {
                res.send("0")
                // console.log(err)
            }
        }
        // console.log(param)
        paymentModel.showOrderNumModel(param,callback)
    },
    changeStatus:function (req,res) {
        let user_id = req.session.userId;
        let uo_id = req.body.uo_id;
        let param=[user_id,uo_id];
        console.log(param)
        function callback(err, data) {
            if (!err) {
                console.log(data)
                res.send(data)
            } else {
                res.send("0")
                console.log(err)
            }
        }
        paymentModel.changeStatusModel(param,callback)
    }
}
module.exports = orderNum;