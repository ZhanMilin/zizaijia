const pccModel=require("../model/pccModel.js")
const fs=require("fs")
const pccControl={
    //我的账户
    myUserInfo:(req,res)=>{
        let user=req.session.user;
        console.log(user)
        if(req.session.user!=null || req.session.user!=undefined){
            res.render("myAccount",{userInfo:user})
        }else{
            res.redirect('HTML/login/login.html')
        }
    },
    //我的订单
    myOrder:(req,res)=>{
        let user=req.session.user;
        let userId=req.session.userId;
        let param=[];
        if(userId!=undefined){
            param.push(userId)
        }
        function callback(err,data) {
            if(!err) {
                if(req.session.user!=null || req.session.user!=undefined){
                    res.render("personalCenterChildren", {title: "我的订单",userInfo:user,userData: data})
                }else{
                    res.redirect('HTML/login/login.html')
                }
            }else{
                res.redirect('HTML/login/login.html')
            }
        }
        pccModel.myOrder(param,callback)
    },
    //配送地址
    address:(req,res)=>{
        let name=req.session.name;
        let user=req.session.user;
        let param=[];
        param.push(name)
        function callback(err,data) {
            if(!err&&data.length>=0){
                if(req.session.user!=null || req.session.user!=undefined){
                    res.render("personalCenterChildren",{title:"配送地址",userInfo:user,userData:data})
                }else{
                    res.redirect('HTML/login/login.html')
                }
            }
        }
        pccModel.userAddress(param,callback)
    },
    //评价晒单
    evaluate:(req,res)=>{
        let name=req.session.name;
        let user=req.session.user;
        let data=[]
        if(req.session.user!=null || req.session.user!=undefined){
            res.render("personalCenterChildren",{title:"评价晒单",userInfo:user,userData:data})
        }else{
            res.redirect('HTML/login/login.html')
        }
    },
    //我的自定制
    selfDefined:(req,res)=>{
        let user=req.session.user;
        let userImg=req.session.userImg
        let data=[]
        if(req.session.user!=null || req.session.user!=undefined){
            res.render("personalCenterChildren",{title:"我的自定制",userInfo_img:userImg,userInfo:user,userData:data})
        }else{
            res.redirect('HTML/login/login.html')
        }
    },
    //我的收藏
    collect:(req,res)=>{
        let userId=req.session.userId;
        let user=req.session.user;
        let param=[];
        param.push(userId)
        function callback(err,data){
            if(!err){
                if(req.session.user!=null || req.session.user!=undefined){
                    res.render("personalCenterChildren",{title:"我的收藏",userInfo:user,userData:data})
                }else{
                    res.redirect('HTML/login/login.html')
                }
            }
        }
        pccModel.collect(param,callback)
    },
    //我的优惠券
    coupon:(req,res)=>{
        let userId=req.session.userId;
        let user=req.session.user;
        let param=[];
        param.push(userId)
        function callback(err,data) {
            if(!err&&data.length>=0){
                if(req.session.user!=null || req.session.user!=undefined){
                    res.render("personalCenterChildren",{title:"我的优惠券",userInfo:user,userData:data})
                }else{
                    res.redirect('HTML/login/login.html')
                }
            }
        }
        pccModel.myCoupon(param,callback)
    },
    //个人信息
    personalInfo:(req,res)=>{
        let name=req.session.name;
        let user=req.session.user;
        let param=[];
        if(name!=undefined){
            param.push(name)
        }
        function callback(err,data) {
            if(!err&&data.length>=0){
                if(req.session.user!=null || req.session.user!=undefined){
                    res.render("personalCenterChildren",{title:"个人信息",userInfo:user,userData:data})
                }else{
                    res.redirect('HTML/login/login.html')
                }
            }
        }
        pccModel.personalInfo(param,callback)
    },
    //我的消息
    myMsg:(req,res)=>{
        let userId=req.session.userId;
        let user=req.session.user;
        let param=[];
        param.push(userId);
        function callback(err,data) {
            if(!err){
                if(req.session.user!=null || req.session.user!=undefined){
                    res.render("personalCenterChildren",{title:"我的消息",userInfo:user,userData:data})
                }else{
                    res.redirect('HTML/login/login.html')
                }
            }
        }
        pccModel.myMsg(param,callback)
    },
    //上传图片
    userHeadImg:(req,res)=>{
      let oldPath=req.files.userFile.path;
      console.log(1)
        console.log(req.files)
      let newPath="public/images/personalCenter/"+req.files.userFile.name;
      req.session.user.userInfo_img=req.files.userFile.name;
      fs.createReadStream(oldPath).pipe(fs.createWriteStream(newPath)).on("close",function (err) {
          if(err==null){
              let param=[];
              let user=req.session.name
              function callback(err,data) {
                  if(!err){
                      req.session.user.userInfo_img=req.files.userFile.name
                      res.send("1")
                  }else{
                      res.send("0")
                  }
              }
              param.push(req.files.userFile.name);
              param.push(user)
              pccModel.userHeadImg(param,callback)
          }
      })
    },
    //保存资料
    saveData:(req,res)=>{
        let user=req.session.name;
        let nickName=req.body.nickName;
        let userName=req.body.userName;
        let sex=req.body.sex;
        let birthday=req.body.birthday;
        let email=req.body.email;
        let param=[];
        if(userName.length==0){
            userName=null;
        }
        if(sex=="请选择性别"){
            sex=null;
        }
        if(birthday=="选择生日"){
            birthday=null;
        }
        if(nickName.length==0){
            nickName=null;
        }
        if(email.length==0){
            email=null;
        }
        param.push(userName);
        param.push(sex);
        param.push(birthday);
        param.push(nickName);
        param.push(email);
        param.push(user);
        function callback(err,data) {
            if(!err){
                req.session.user.userInfo_nickname=nickName;
                res.send("1")
            }else{
                res.send("0")
            }
        }
        pccModel.saveData(param,callback)
    },
    //匹配密码
    matchPwd: (req,res)=>{
        let pwd=req.body.pwd;
        let name=req.session.name;
        let param=[];
        param.push(pwd);
        param.push(name);
        function callback(err,data) {
            if(!err&&data.length>0){
                res.send("1")
            }else{
                res.send("0")
            }
        }
        pccModel.matchPwd(param,callback)
    },
    //修改密码
    changPwd:(req,res)=>{
        let newPwd=req.body.newPwd;
        let name=req.session.name;
        let param=[];
        param.push(newPwd);
        param.push(name);
        function callback(err,data) {
            if(!err){
                res.send("1")
            }else{
                res.send("0")
            }
        }
        pccModel.changPwd(param,callback)
    },
    //添加地址
    myAddress:(req,res)=>{
        let userName=req.body.name;
        let tel=req.body.tel;
        let province=req.body.province;
        let city=req.body.city;
        let district=req.body.district;
        let minute=req.body.minute;
        let name=req.session.name;
        let param=[];
        param.push(userName)
        param.push(tel)
        param.push(province)
        param.push(city)
        param.push(district)
        param.push(minute)
        param.push(name)
        function callback(err,data) {
            if(!err){
                res.send("1")
            }else{
                res.send("0")
            }
        }
        pccModel.myAddress(param,callback)
    },
    //编辑地址获取地址信息
    compileAdd:(req,res)=>{
        let addId=req.body.addId;
        let userId=req.session.userId;
        let param=[];
        param.push(addId);
        param.push(userId);
        function callback(err,data) {
            if(!err&&data.length>0){
                let myData=JSON.stringify(data)
                res.send(myData)
            }
        }
        pccModel.compileAdd(param,callback)
    },
    //编辑地址修改数据库
    alterAddress:(req,res)=>{
        let userName=req.body.name;
        let tel=req.body.tel;
        let province=req.body.province;
        let city=req.body.city;
        let district=req.body.district;
        let minute=req.body.minute;
        let userId=req.session.userId;
        let userAddId=Number(req.body.userAddId);
        let param=[];
        param.push(userName)
        param.push(tel)
        param.push(province)
        param.push(city)
        param.push(district)
        param.push(minute)
        param.push(userId)
        param.push(userAddId)
        function callback(err,data) {
            if(!err){
                res.send("1")
            }else{
                res.send("0")
            }
        }
        pccModel.alterAddress(param,callback)
    },
    //删除地址
    deleteAdd:(req,res)=>{
        let addId=req.body.addId;
        let param=[];
        param.push(addId);
        function callback(err,data) {
            if(!err){
                res.send("1")
            }
        }
        pccModel.deleteAdd(param,callback)
    },
    //查询用户已使用优惠券信息
    userHasUse:(req,res)=>{
        let addId=req.session.userId;
        let param=[];
        param.push(addId);
        function callback(err,data) {
            if(!err&&data.length>=0){
                data=JSON.stringify(data)
                res.send(data)
            }
        }
        pccModel.userHasUse(param,callback)
    },
    //查询用户可使用优惠券信息
    userEnable:(req,res)=>{
        let addId=req.session.userId;
        let param=[];
        param.push(addId);
        function callback(err,data) {
            if(!err&&data.length>=0){
                data=JSON.stringify(data)
                res.send(data)
            }
        }
        pccModel.userEnable(param,callback)
    },
    //查询用户已过期优惠券信息
    userStale:(req,res)=>{
        let addId=req.session.userId;
        let param=[];
        param.push(addId);
        function callback(err,data) {
            if(!err&&data.length>=0){
                data=JSON.stringify(data)
                res.send(data)
            }
        }
        pccModel.userStale(param,callback)
    },
    //用户查询待付款订单信息
    myObligation:(req,res)=>{
        let userId=req.session.userId;
        let param=[];
        if(userId!=undefined){
            param.push(userId)
        }
        function callback(err,data) {
            if(!err) {
                data=JSON.stringify(data);
                res.send(data)
            }
        }
        pccModel.myObligation(param,callback)
    },
    //用户查询待发货订单信息
    mySendGood:(req,res)=>{
        let userId=req.session.userId;
        let param=[];
        if(userId!=undefined){
            param.push(userId)
        }
        function callback(err,data) {
            if(!err) {
                data=JSON.stringify(data);
                res.send(data)
            }
        }
        pccModel.mySendGood(param,callback)
    },
    //用户查询待收货订单信息
    myTrs:(req,res)=>{
        let userId=req.session.userId;
        let param=[];
        if(userId!=undefined){
            param.push(userId)
        }
        function callback(err,data) {
            if(!err) {
                data=JSON.stringify(data);
                res.send(data)
            }
        }
        pccModel.myTrs(param,callback)
    },
    //用户查询已完成订单信息
    myFinish:(req,res)=>{
        let userId=req.session.userId;
        let param=[];
        if(userId!=undefined){
            param.push(userId)
        }
        function callback(err,data) {
            if(!err) {
                data=JSON.stringify(data);
                res.send(data)
            }
        }
        pccModel.myFinish(param,callback)
    },
    //用户查询所有订单信息
    myUserOrder:(req,res)=>{
        let userId=req.session.userId;
        let param=[];
        if(userId!=undefined){
            param.push(userId)
        }
        function callback(err,data) {
            if(!err) {
                data=JSON.stringify(data);
                res.send(data)
            }
        }
        pccModel.myUserOrder(param,callback)
    },
    //用户删除订单信息
    deleteOrder:(req,res)=>{
        let id=req.body.id;
        let userId=req.session.userId;
        let param=[];
        param.push(id,userId);
        function callback(err,data) {
            if(!err){
                res.send("1")
            }else{
                res.send("2")
            }
        }
        pccModel.deleteOrder(param,callback)
    },
    //用户批量删除订单
    myDeleteBatch:(req,res)=>{
        let str=req.body.id;
        let userId=req.session.userId;
        let param;
        param=str.split(",");
        param.push(userId)
        console.log(param)
        function callback(err,data) {
            if(!err){
                res.send("1")
            }else{
                res.send("2")
            }
        }
        let sql="delete from userorder where uo_id in("
        for(let i=0;i<param.length-2;i++){
            sql+="?,"
        }
        sql+="?) and user_id=?"
        pccModel.myDeleteBatch(sql,param,callback)
    },
    //用户设置默认地址
    defaultAdd:(req,res)=>{
        let addId=req.body.addId;
        let userId=req.session.userId;
        let param=[];
        param.push(addId,userId)
        function callback(err,data) {
            if(!err){
                res.send("1")
            }else{
                res.send("2")
            }
        }
        function callback1(err,data) {
            if(!err){
                pccModel.defaultAdd(param,callback)
            }else{
                res.send("2")
            }
        }
        pccModel.changeAddStatus([userId],callback1)
    },
    //用户查看消息后改变消息状态
    changeMsgStatus:(req,res)=>{
        let userId=req.session.userId;
        let MsgId=req.body.MsgId;
        let param=[];
        param.push(MsgId,userId)
        function callback(err,data) {
            if(!err){
                pccModel.getMsgContent(param,callback1)
            }
        }
        function callback1(err,data) {
            if(!err&&data.length>0){
                let myData=JSON.stringify(data)
                res.send(myData)
            }
        }
        pccModel.changeMsgStatus(param,callback)
    },
    //用户查询所有消息
    userAllMsg:(req,res)=>{
        let userId=req.session.userId;
        let param=[];
        param.push(userId)
        function callback(err,data) {
            if(!err){
                let myDate=JSON.stringify(data)
                res.send(myDate)
            }
        }
        pccModel.userAllMsg(param,callback)
    },
    //用户查询新消息
    userNewMsg:(req,res)=>{
        let userId=req.session.userId;
        let param=[];
        param.push(userId)
        function callback(err,data) {
            if(!err){
                let myDate=JSON.stringify(data)
                res.send(myDate)
            }
        }
        pccModel.userNewMsg(param,callback)
    },
    //用户查询新消息
    userReadyMsg:(req,res)=>{
        let userId=req.session.userId;
        let param=[];
        param.push(userId)
        function callback(err,data) {
            if(!err){
                let myDate=JSON.stringify(data)
                res.send(myDate)
            }
        }
        pccModel.userReadyMsg(param,callback)
    },
    //用户删除我的收藏
    deleteMyCollect:function (req,res) {
        let ucId=req.body.ucId;
        let param=[];
        param.push(ucId)
        function callback(err,data) {
            if(!err){
                res.send("1")
            }
        }
        pccModel.deleteMyCollect(param,callback)
    },
    //用户确认收货改变订单状态
    goodProduct:function (req,res) {
        let uoId=req.body.uo_id;
        let userId=req.session.userId
        let param=[];
        param.push(uoId)
        param.push(userId)
        function callback(err,data) {
            if(!err){
                res.send("1")
            }
        }
        pccModel.goodProduct(param,callback)
    }
}
module.exports=pccControl