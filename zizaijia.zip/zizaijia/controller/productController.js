const productModel = require("../model/productModel.js");
//=============遍历=============================================
function ProductList1(request,response) {
    let text1 = request.query.text1;
    let text2 = request.query.text2;
    let text3 = request.query.text3;
    let text4 = request.query.text4;
    let text5 = request.query.text5;
    let text6 = request.query.text6;
    let page = request.query.page;
    page = (page-1)*12;
    let param = [];
    let sql = "select color_value,product_id,product_cover,class_name,product_name,product_sale from (product inner join class on " +
        "product.class_id=class.class_id) inner join color on product.color_id=color.color_id where 1=1";
    if (text1 != "") {
        param.push(text1);
        sql = sql + " and product_style=?";
    }
    if (text2 != "") {
        param.push(text2);
        sql = sql + " and class_name = ?";
    }
    if (text3 != "") {
        param.push(text3);
        sql = sql + " and product_material=?";
    }
    if (text4 != "") {
        let preText4;
        if(text4=="7000元以上"){
            param.push(7000)
            sql=sql+" and product_sale>?"
        }else{
            preText4 = text4.substr(0,text4.length-1);
            let newText4 = preText4.split("-");
            param.push(newText4[0]);
            param.push(newText4[1]);
            sql = sql+" and product_sale between ? and ?";
        }
    }
    if(text5 != ""){
       text5 = "#"+text5;
        param.push(text5);
        param.push(page);
        sql = sql+" and color_value=?";
    }
    if(text6!=""){
        sql = sql+" order by product_sale desc";
    }
    param.push(page);
    sql = sql+" limit ?,12";
    function callback(err, data) {
        if (err == null && data.length >= 0) {
            let productData = JSON.stringify(data);
            response.send(productData);
        } else {
            response.send("没有查询数据");
        }
    }
    productModel.getProductList(sql,param,callback);
}
function pageCount1(request,response){
    let text1 = request.query.text1;
    let text2 = request.query.text2;
    let text3 = request.query.text3;
    let text4 = request.query.text4;
    let text5 = request.query.text5;
    let param=[];
   let sql = "SELECT COUNT(*) as productNum FROM (product INNER JOIN class ON \n" +
       "product.class_id=class.class_id) INNER JOIN color ON product.color_id=color.color_id WHERE 1=1";
    if(text1 != ""){
        param.push(text1);
        sql = sql+" and product_style=?";
    }
    if(text2!=""){
        param.push(text2);
        sql = sql +" and class_name=?";
    }
    if(text3!=""){
        param.push(text3);
        sql = sql+" and product_material=?"
    }
    if(text4 != ""){
        let preText4;
        if(text4=="7000元以上"){
            param.push(7000)
            sql=sql+" and product_sale>?"
        }else{
            preText4 = text4.substr(0,text4.length-1);
            let newText4 = preText4.split("-");
            param.push(newText4[0]);
            param.push(newText4[1]);
            sql = sql+" and product_sale between ? and ?";
        }
    }
    if(text5 !=""){
        text5 = "#"+text5;
        param.push(text5);
        sql = sql+" and color_value=?"
    }
    function callback(err,data){
        if(err == null && data.length>0){
            let count = Math.ceil(data[0].productNum/12);
            response.send(String(count));
        }else{
            response.send("没有查到数据");
        }
    }
    productModel.getPageCount(sql,param,callback);
}
/*function productStyle1(request,response){
    function callback(err,data){
        if(err == null && data.length>0)
        console.log(data);
        let productStyle = JSON.stringify(data);
        response.send(productStyle);
    }
    productModel.getStyle(callback);
}*/
module.exports = {
    productList:ProductList1,
    pageCount:pageCount1,
    // productStyle:productStyle1
};