const orderModel = require("../model/orderModel.js")
let orderInfo = {
    //添加地址ejs
    addOrderAddEjs:function (req, res) {
                res.render("orderAdd")
    },
    //添加地址
    addOrderAdd:function (req,res) {
        let addPrame=[]
        addPrame.push(req.session.userId)
        addPrame.push(req.query.s_province)
        addPrame.push(req.query.s_city)
        addPrame.push(req.query.s_county)
        addPrame.push(req.query.orderAddAdd)
        addPrame.push(req.query.orderAddName)
        addPrame.push(req.query.orderAddPhone)
        function cb(err, data) {
            if(!err){
                res.send("1")
            }
        }
        orderModel.addAddress(addPrame,cb)
    },
    orderAEjs:function (req,res) {
        res.render("order")
    },
    //订单页面跳转
    orderEjs:function (req, res) {
        var userId = req.session.userId
        var id = req.query.id
        // console.log("id====="+id)
        var myDiscount = null;
        var myProductInfo;
        var myProductId =[];
        var myProductImg=[]

        //获取商品订单id
        function cb3(err,data) {
            if(!err&&data.length>0){
                myProductInfo=data
                for(var i=0;i<data.length;i++){
                    myProductId = data[i].product_id
                    orderModel.getProductImg(myProductId,cb4)
                }
            }
        }
        orderModel.getProductInfo(id,cb3)
        orderModel.getDiscount(userId,cb1)

        //获取商品详情
        function cb4(err, data) {
            if(!err&&data.length>0){
                myProductImg.push(data)
                if(myProductInfo.length==myProductImg.length){
                    orderModel.getUserAdd(userId,cb2)
                }
            }
        }

        //获取优惠券数据
        function cb1(err, data) {
            if(!err) {
                myDiscount = data
            }
        }

        //返回地址 返回订单确认EJS
        function cb2(err, data) {
            if(!err){
                res.render("order",{userAdd:data,discount:myDiscount,productInfo:myProductInfo,productImg:myProductImg})
            }
        }
    },
    //订单地址修改ejs
    orderAddUpdataEjs:function (req, res) {
        var addId=req.query.addId
        function cb(err, data) {
            if(!err){
                res.render("orderAddUpdate",{addId:data})
            }
        }
        orderModel.getAdd(addId,cb)
    },
    //修改地址
    orderAddUpdata:function (req, res) {
        let addPrame=[]
        addPrame.push(req.query.s_province)
        addPrame.push(req.query.s_city)
        addPrame.push(req.query.s_county)
        addPrame.push(req.query.orderAddAdd)
        addPrame.push(req.query.orderAddName)
        addPrame.push(req.query.orderAddPhone)
        addPrame.push(req.query.addid)
        function cb(err, data) {
            if(!err){
                res.send("1")
            }
        }
        orderModel.updateAddress(addPrame,cb)
    },

    //添加地址
    addOrder:function (req,res) {
        let productInfo = req.body.productInfo
        let addId = req.body.addId
        let myTotalprices = req.body.myTotalprices
        let userId=req.session.userId
        let addInfo=[]
        let orderInfo=[]

        //获取地址
        function cb(err, data) {
            if(!err&&data!=null){
                addInfo.push(data[0].userAdd_pro)
                addInfo.push(data[0].userAdd_city)
                addInfo.push(data[0].userAdd_district)
                addInfo.push(data[0].userAdd_add)
                addInfo.push(data[0].username)
                addInfo.push(data[0].userTel)
                orderModel.addTempAdd(addInfo,cb1)
            }
        }

        orderModel.getAdd(addId,cb)

        //添加临时地址
        function cb1(err, data) {
            if(!err&&data!=null){
                var inserId = data.insertId
                orderInfo.push(userId)
                orderInfo.push(inserId)
                orderInfo.push(1)
                orderInfo.push(myTotalprices)
                var myDate = new Date()
                orderInfo.push(myDate.getFullYear()+"-"+(myDate.getMonth()+1)+"-"+myDate.getDate())
                orderModel.addOrderInfo(orderInfo,cb2)
            }
        }

        //添加订单
        var orderId
        function cb2(err, data) {
            if(!err&&data!=null) {
                res.send(data)
                orderId = data.insertId
                orderModel.getProductId(productInfo,cb3)
            }
        }

        //获取商品信息
        var collect
        function cb3(err, data) {
            if(!err&&data!=null) {
                for(var i=0;i<data.length;i++){
                    var myData=[]
                    myData.push(orderId)
                    myData.push(data[i].product_id)
                    myData.push(data[i].product_num)
                    orderModel.addOrderProduct(myData,cb4)
                }
            }
        }
        function cb4(err, data) {
        }
    }
}
module.exports = orderInfo;