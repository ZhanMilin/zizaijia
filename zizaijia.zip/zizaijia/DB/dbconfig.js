const mysql=require("mysql");
const mysqlConfig={
    config:{
        host:"192.168.3.245",
        user:"root",
        password:"",
        port:"3306",
        database:"happyresidence"
    },
    // config:{
    //     host:"localhost",
    //     user:"root",
    //     password:"root",
    //     port:"3306",
    //     database:"happyresidence"
    // },
    connection:function (sql,param,cb){
        "use strict";
        let myConnect=mysql.createConnection(this.config);
        myConnect.connect();
        myConnect.query(sql,param,cb);
        myConnect.end()
    }
};
module.exports=mysqlConfig;