const gulp=require("gulp")
const less=require("gulp-less")
const bs=require("browser-sync")
gulp.task("gulpLogin",()=>{
    gulp.src("./src/HTML/login.html")
        .pipe(gulp.dest("./public/HTML/"))
})
gulp.task("gulpLogin.js",()=>{
    gulp.src("./src/JS/userLogin.js")
        .pipe(gulp.dest("./public/JS/"))
})
gulp.task("less",()=>{
    gulp.src("./public/LESS/myAccount.less")
        .pipe(less())
        .pipe(gulp.dest("./public/CSS/"))
})
gulp.task("personalLess",()=>{
    gulp.src("./public/LESS/personalCenterChildren.less")
        .pipe(less())
        .pipe(gulp.dest("./public/CSS/"))
})
gulp.task("footerInfoLess",()=>{
    gulp.src("./public/less/footerInfo.less")
        .pipe(less())
        .pipe(gulp.dest("./public/CSS/personalCenterChildren.css"))
})
//监听less
gulp.task("watchLess",()=>{
    gulp.watch("./public/LESS/myAccount.less",["less"])
})
//
gulp.task("watchPersonalLess",()=>{
    gulp.watch("./public/LESS/personalCenterChildren.less",["personalLess"])
})
//监听login.HTML
gulp.task("watch",()=>{
    gulp.watch("src/HTML/login.html",["gulpLogin"])
})
//监听login.JS
gulp.task("watchLogin.js",()=>{
    gulp.watch("src/JS/userLogin.js",["gulpLogin.js"])
})

gulp.task("bs-server",function () {
    let files=["./public/LESS/*.less","./public/HTML/personalCenter/*.html","./public/CSS/*.css","./public/JS/*.js"];
    bs.init(files,{
        server:{
            baseDir:"./public/"
        }
    })
})
gulp.task("bs-server1",function () {
    let files=["./views/*.ejs","./public/CSS/*.css","./public/JS/*.js"];
    bs.init(files,{
        server:{
            baseDir:"./views/"
        }
    })
})